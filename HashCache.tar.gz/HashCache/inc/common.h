#ifndef _COMMON_H_
#define _COMMON_H_

int writen( int fd, char *data, int n );
int readn( int fd, void *data, int n );

#endif
