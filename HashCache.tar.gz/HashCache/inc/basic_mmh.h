#ifndef _BASIC_MMH_H_
#define _BASIC_MMH_H_

unsigned long basic_mmh( unsigned long *rands, unsigned long *URLSHA1, int size );

#endif

